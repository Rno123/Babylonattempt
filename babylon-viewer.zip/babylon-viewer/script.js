// Dependencies
let BabylonViewer = require('babylonjs-viewer');

// @TODO Declare currentViewer object below
let currentViewer;

// define models object
let models = {
  rabbit : {
    title: "Rabbit",
    subtitle: "BabylonJS",
    thumbnail: "https://www.babylonjs.com/img/favicon/apple-icon-144x144.png",
    url: "https://playground.babylonjs.com/scenes/Rabbit.babylon"
  },
  helmet : {
    title: "Helmet",
    subtitle: "BabylonJS",
    thumbnail: "https://www.babylonjs.com/img/favicon/apple-icon-144x144.png",
    url: "https://www.babylonjs.com/Assets/DamagedHelmet/glTF/DamagedHelmet.gltf"
  }
}

// Get the viewer by ID
BabylonViewer.viewerManager.getViewerPromiseById('babylon-viewer').then(function (viewer) {
    // @TODO Save the declared viewer as a variable for use later
    currentViewer = viewer
    // this will resolve only after the viewer with this specific ID is initialized
    viewer.onEngineInitObservable.add(function (scene) {

        viewer.loadModel(models.rabbit).then(model => {
          // @TODO Save the title of the model to sessionStorage https://www.w3schools.com/jsref/prop_win_sessionstorage.asp
          sessionStorage.setItem("title", model._modelConfiguration.title);
        });
    });
});

// @TODO Add an event listener for a key press (spacebar is 32) to change the model
function toggleModel(key) {
  if (key.keyCode == '32') {
    currentModelTitle = sessionStorage.getItem("title");
    console.log(sessionStorage.getItem("title"));
    if (currentModelTitle == 'Rabbit') {
      currentViewer.loadModel(models.helmet).then(model => {
        sessionStorage.setItem("title", model._modelConfiguration.title);
      });
    } else if (currentModelTitle == 'Helmet'){
      currentViewer.loadModel(models.rabbit).then(model => {
        sessionStorage.setItem("title", model._modelConfiguration.title);
      });
    }
  }
};

addEventListener("keypress", toggleModel, false);
